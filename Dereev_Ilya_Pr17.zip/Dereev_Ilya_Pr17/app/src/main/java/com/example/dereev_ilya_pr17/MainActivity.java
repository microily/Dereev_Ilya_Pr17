package com.example.dereev_ilya_pr17;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
public class MainActivity extends Activity implements OnClickListener {
    final String LOG_TAG = "myLogs";
    String planes[] = { "Як-38", "ЛаГГ-3", "Ил-76", "МиГ-31", "Ту-144",
            "Як-58", "Boeing 797", "McDonnell Douglas MD-11", "British Aerospace P.125", "Junkers Ju 87" };
    int amount[] = { 400, 500, 800, 300, 750, 370, 650, 120, 960, 610 };
    String country[] = { "СССР", "СССР", "", "СССР", "СССР",
            "СССР", "USA", "USA", "British", "Germany" };
    Button btnAll, btnFunc, btnAmount, btnSort, btnGroup, btnHaving;
    EditText etFunc, etAmount, etCountryAmount;
    RadioGroup rgSort;
    DBHelper dbHelper;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAll = (Button) findViewById(R.id.btnAll);
        btnAll.setOnClickListener(this);
        btnFunc = (Button) findViewById(R.id.btnFunc);
        btnFunc.setOnClickListener(this);
        btnAmount = (Button) findViewById(R.id.btnAmount);
        btnAmount.setOnClickListener(this);
        btnSort = (Button) findViewById(R.id.btnSort);
        btnSort.setOnClickListener(this);
        btnGroup = (Button) findViewById(R.id.btnGroup);
        btnGroup.setOnClickListener(this);
        btnHaving = (Button) findViewById(R.id.btnHaving);
        btnHaving.setOnClickListener(this);
        etFunc = (EditText) findViewById(R.id.etFunc);
        etAmount = (EditText) findViewById(R.id.etAmount);
        etCountryAmount = (EditText) findViewById(R.id.etCountryAmount);
        rgSort = (RadioGroup) findViewById(R.id.rgSort);
        dbHelper = new DBHelper(this);
        // подключаемся к базе
        db = dbHelper.getWritableDatabase();
        // проверка существования записей
        Cursor c = db.query("mytable", null, null, null, null, null, null);
        if (c.getCount() == 0) {
            ContentValues cv = new ContentValues();
            // заполним таблицу
            for (int i = 0; i < 10; i++) {
                cv.put("planes", planes[i]);
                cv.put("amount", amount[i]);
                cv.put("country", country[i]);
                Log.d(LOG_TAG, "id = " + db.insert("mytable", null, cv));
            }
        }
        c.close();
        dbHelper.close();
        // эмулируем нажатие кнопки btnAll
        onClick(btnAll);
    }
    @SuppressLint("Range")
    public void onClick(View v) {
        // подключаемся к базе
        db = dbHelper.getWritableDatabase();
        // данные с экрана
        String sFunc = etFunc.getText().toString();
        String sAmount = etAmount.getText().toString();
        String sCountryAmount = etCountryAmount.getText().toString();
        // переменные для query
        String[] columns = null;
        String selection = null;
        String[] selectionArgs = null;
        String groupBy = null;
        String having = null;
        String orderBy = null;
        // курсор
        Cursor c = null;
        // определяем нажатую кнопку
        if (v.getId() == R.id.btnAll) {
            Log.d(LOG_TAG, "--- Все записи ---");
            c = db.query("mytable", null, null, null, null, null, null);
        } else if (v.getId() == R.id.btnFunc) {
            Log.d(LOG_TAG, "--- Функция " + sFunc + " ---");
            columns = new String[] { sFunc };
            c = db.query("mytable", columns, null, null, null, null, null);
        } else if (v.getId() == R.id.btnAmount) {
            Log.d(LOG_TAG, "--- Количество больше " + sAmount + " ---");
            selection = "amount > ?";
            selectionArgs = new String[] { sAmount };
            c = db.query("mytable", null, selection, selectionArgs, null, null, null);
        } else if (v.getId() == R.id.btnGroup) {
            Log.d(LOG_TAG, "--- Количество по стране ---");
            columns = new String[] { "country", "sum(amount) as amount" };
            groupBy = "country";
            c = db.query("mytable", columns, null, null, groupBy, null, null);
        } else if (v.getId() == R.id.btnHaving) {
            Log.d(LOG_TAG, "--- Страна с количеством больше " + sCountryAmount + " ---");
            columns = new String[] { "country", "sum(amount) as amount" };
            groupBy = "country";
            having = "sum(amount) > " + sCountryAmount;
            c = db.query("mytable", columns, null, null, groupBy, having, null);
        } else if (v.getId() == R.id.btnSort) {
            // сортировка по
            if (rgSort.getCheckedRadioButtonId() == R.id.rName) {
                Log.d(LOG_TAG, "--- Сортировка по названию ---");
                orderBy = "planes";
            } else if (rgSort.getCheckedRadioButtonId() == R.id.rAmount) {
                Log.d(LOG_TAG, "--- Сортировка по количеству ---");
                orderBy = "amount";
            } else if (rgSort.getCheckedRadioButtonId() == R.id.rCountry) {
                Log.d(LOG_TAG, "--- Сортировка по стране ---");
                orderBy = "country";
            }
            c = db.query("mytable", null, null, null, null, null, orderBy);
        }
        if (c != null) {
            if (c.moveToFirst()) {
                String str;
                do {
                    str = "";
                    for (String cn : c.getColumnNames()) {
                        str = str.concat(cn + " = "
                                + c.getString(c.getColumnIndex(cn)) + "; ");
                    }
                    Log.d(LOG_TAG, str);
                } while (c.moveToNext());
            }
            c.close();
        } else
            Log.d(LOG_TAG, "Cursor is null");
        dbHelper.close();
    }
    class DBHelper extends SQLiteOpenHelper {
        public DBHelper(Context context) {
            // конструктор суперкласса
            super(context, "myDB", null, 1);
        }
        public void onCreate(SQLiteDatabase db) {
            Log.d(LOG_TAG, "--- onCreate database ---");
            // создаем таблицу с полями
            db.execSQL("create table mytable ("
                    + "id integer primary key autoincrement,planes" + " text,amount"
                    + " integer,country" + " text" + ");");
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        }
    }
}